package lk.ijse.gdse66.webBackEnd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
